import React from 'react';

export default function Dashboard() {
  return (
    <div style={{padding:'20px'}}>
      <h2>Dashboard</h2>
      <p>Your tasks will appear here.</p>
    </div>
  );
}
