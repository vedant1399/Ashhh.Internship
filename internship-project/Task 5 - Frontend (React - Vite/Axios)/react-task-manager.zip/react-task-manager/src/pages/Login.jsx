import React, { useState } from 'react';
import axios from 'axios';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      const res = await axios.post('http://localhost:8000/api/login/', {
        username, password
      });
      localStorage.setItem('token', res.data.token);
      alert('Login Successful');
    } catch (err) {
      alert('Login Failed');
    }
  };

  return (
    <div style={{padding:'20px'}}>
      <h2>Login</h2>
      <input placeholder="Username" onChange={e => setUsername(e.target.value)} />
      <br/><br/>
      <input placeholder="Password" type="password" onChange={e => setPassword(e.target.value)} />
      <br/><br/>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}
